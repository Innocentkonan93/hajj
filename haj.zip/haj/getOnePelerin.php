<?php

include('db/db.php');

$id_pel = $_GET['id_pel'];
// $id_pel = '1';


$sql=$db->query("SELECT * FROM tshajj_pelerin WHERE id_pel = $id_pel ");

$res=array();

while ($row=$sql->fetch()) {
    $res[]=$row;
}

echo json_encode($res);


?>