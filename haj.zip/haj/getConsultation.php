<?php

include('db/db.php');



$sql=$db->query("SELECT * FROM consultation_pelerin ORDER BY date_consul DESC");

$res=array();

while ($row=$sql->fetch()) {
    $res[]=$row;
}

echo json_encode($res);

?>