<?php

include('db/db.php');

$nom_pel = $_POST['nom_pel'];
$prenom_pel = $_POST['prenom_pel'];
$temperature_pel = $_POST['temperature_pel'];
$tension_pel = $_POST['tension_pel'];
$symptomes_pel = $_POST['symptomes_pel'];
$prescription_pel = $_POST['prescription_pel'];



$newConsul = [
'nom_pel' => $nom_pel,
'prenom_pel' => $prenom_pel,
'temperature_pel' => $temperature_pel,
'tension_pel' => $tension_pel,
'symptomes_pel' => $symptomes_pel,
'prescription_pel' => $prescription_pel,
];


$sql1 = "INSERT INTO consultation_pelerin (nom_pel, prenom_pel, temperature_pel, tension_pel, symptomes_pel, prescription_pel) VALUES (:nom_pel, :prenom_pel, :temperature_pel, :tension_pel, :symptomes_pel, :prescription_pel)";
$stmt1 = $db->prepare($sql1);
$stmt1->execute($newConsul);


echo json_encode('success');



?>